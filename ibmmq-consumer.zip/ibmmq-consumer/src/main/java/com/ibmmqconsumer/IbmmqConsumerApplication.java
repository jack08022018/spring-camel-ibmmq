package com.ibmmqconsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IbmmqConsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(IbmmqConsumerApplication.class, args);
	}

}
